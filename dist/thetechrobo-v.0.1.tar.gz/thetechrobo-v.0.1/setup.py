from distutils.core import setup

setup(
    name='thetechrobo',
    version='v.0.1',
    packages=['cprint','exp'],
    license='Artistic License',
    long_description="I add Literally any idea that pops into my head",
    description="from thetechrobo import * -- my misc package",
    author='Ittussarom Ynohtna @TheTechRobo',
	url='https://github.com/thetechrobo/python-text-calculator-plus',
)