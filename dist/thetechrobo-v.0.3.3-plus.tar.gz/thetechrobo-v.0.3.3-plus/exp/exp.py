def two(number):
    print(number * number)
def three(number):
    print(number * number * number)
def sq(number):
    two(number)
def cu(number):
    three(number)
def four(number):
    print(number * number * number * number)
def five(number):
    print(number * number * number * number * number)